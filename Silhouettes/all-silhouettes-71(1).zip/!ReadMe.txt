That file was downloaded from AllSilhouettes.com

License: 

You are free: 
to Share � to copy, distribute and transmit the work
to Remix � to adapt the work
You may use this work for commercial purposes.

I'm spending my time to create all that silhouettes and
I would really appreciate a link back or a few words.

