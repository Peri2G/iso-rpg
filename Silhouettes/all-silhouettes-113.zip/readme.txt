Silluettes created from free font -

Sexy Silouette Stencils
Freeware Fontography by Darrian

http://westwood.fortunecity.com/cerruti/445/